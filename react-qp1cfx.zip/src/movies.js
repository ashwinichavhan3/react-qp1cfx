// some sample movies
const initialMovies = {movie1: [
              {
                id:1,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:2,
                title: "Cloudy with a chance of meatballs",
                year: "2009",
                description: "Animated science fiction comedy film",
                poster: "./posters/bridget-jones.png",
                cast: "Chris, phil",
                rating: "6.9/10"
              },
              {
                id:3,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:4,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:5,
                title: "Cloudy with a chance of meatballs",
                year: "2009",
                description: "Animated science fiction comedy film",
                poster: "./posters/bridget-jones.png",
                cast: "Chris, phil",
                rating: "6.9/10"
              },
              {
                id:6,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:7,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:8,
                title: "Cloudy with a chance of meatballs",
                year: "2009",
                description: "Animated science fiction comedy film",
                poster: "./posters/bridget-jones.png",
                cast: "Chris, phil",
                rating: "6.9/10"
              },
              {
                id:9,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:10,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              },
              {
                id:11,
                title: "Cloudy with a chance of meatballs",
                year: "2009",
                description: "Animated science fiction comedy film",
                poster: "./posters/bridget-jones.png",
                cast: "Chris, phil",
                rating: "6.9/10"
              },
              {
                id:12,
                title: "Coco",
                year: "2017",
                description: "American 3D computer animated fantasy film.",
                poster: "./posters/ferris.png",
                cast: "Miguel, Lee",
                rating: "8.4/10"
              }
    ]
    }
 
export {initialMovies};